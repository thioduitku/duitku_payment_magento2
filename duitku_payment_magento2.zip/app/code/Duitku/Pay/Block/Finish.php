<?php
namespace Duitku\Pay\Block;
use Magento\Framework\Registry;
use \Magento\Framework\View\Element\Template;
use \Magento\Framework\View\Element\Template\Context;
class Finish extends Template {
  protected $registry;
  public function __construct(Context $context, Registry $registry) {
    parent::__construct($context);
    $this->registry = $registry;
  }
  public function statTransaction() {

    $detailTransaction['merchant_order_id'] = $this->registry->registry('merchantOrderId');
    $detailTransaction['reference'] = $this->registry->registry('reference');
    $detailTransaction['amount'] = $this->registry->registry('amount');
    $detailTransaction['status_code'] = $this->registry->registry('statusCode');
    $detailTransaction['status_message'] = $this->registry->registry('statusMessage');
    $detailTransaction['fee'] = $this->registry->registry('fee');

    return $detailTransaction;
  }
}
