<?php
namespace Duitku\Pay\Block\Form;
class Duitkupay extends \Magento\Payment\Block\Form {
  protected $_template = 'form/duitkupay.phtml';
}
