<?php
namespace Duitku\Pay\Controller\Index;
use Exception;
use Magento\Checkout\Model\Session;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Registry;
use Magento\Framework\View\Result\PageFactory;
use Magento\Quote\Model\Quote;
use Magento\Sales\Model\OrderFactory;

class Finish extends Action {
  protected $registry;
  protected $_resultPageFactory;
  protected $_checkoutSession;
  protected $_orderFactory;
  public function __construct(Context $context, Registry $registry, PageFactory $pageFactory, Session $checkoutSession, OrderFactory $orderFactory) {
    $this->_resultPageFactory = $pageFactory;
    parent::__construct($context);
    $this->registry = $registry;
    $this->_checkoutSession = $checkoutSession;
    $this->_orderFactory = $orderFactory;
  }
  public function execute() {
    if (!$this->_objectManager->get(\Magento\Checkout\Model\Session\SuccessValidator::class)->isValid()) {
      return $this->resultRedirectFactory->create()->setPath('checkout/cart');
    }
    $om = $this->_objectManager;
    $config = $om->get('Magento\Framework\App\Config\ScopeConfigInterface');
    $url = 'https://dev-new.duitku.com/api/merchant/transactionStatus';
    $apiKey = $config->getValue('payment/duitkupay/api_key', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    $merchantCode = $config->getValue('payment/duitkupay/merchant_code', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    $merchantOrder = $this->_checkoutSession->getLastRealOrder();
    $merchantOrderId = $merchantOrder->getId();
    $signature = md5($merchantCode . $merchantOrderId . $apiKey);
    $params = array(
      'merchantCode' => $merchantCode,
      'merchantOrderId' => $merchantOrderId,
      'signature' => $signature
    );
    
    if (extension_loaded('curl')) {
      try {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
          'Content-Type: application/json'
        ));
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));
        // Receive server response ...
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $server_output = curl_exec($ch);
        curl_close ($ch);

        $respondStatus = json_decode($server_output);

        $respondMerchantOrderId = $respondStatus->merchantOrderId;
        $respondReference = $respondStatus->reference;
        $respondAmount = $respondStatus->amount;
        $respondStatusCode = $respondStatus->statusCode;
        $respondStatusMessage = $respondStatus->statusMessage;
        $respondFee = $respondStatus->fee;

        $this->registry->register('merchantOrderId', $respondMerchantOrderId, false);
        $this->registry->register('reference', $respondReference, false);
        $this->registry->register('amount', $respondAmount, false);
        $this->registry->register('statusCode', $respondStatusCode, false);
        $this->registry->register('statusMessage', $respondStatusMessage, false);
        $this->registry->register('fee', $respondFee, false);
      } catch (Exception $e) {
        error_log($e->getMessage());
        echo $e->getMessage();
      }
    }else{
      throw new Exception("Duitku payment need curl extension, please enable curl extension in your web server");
    }
    $resultPage = $this->_resultPageFactory->create();
    return $resultPage;
  }
}
