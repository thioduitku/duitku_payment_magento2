<?php

namespace Duitku\Pay\Controller\Payment;

use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Controller\ResultFactory;

class Cancel extends \Magento\Framework\App\Action\Action {
  protected $_checkoutSession;
  protected $_logger;
  protected $_coreSession;

  public function __construct(\Magento\Framework\App\Action\Context $context, \Magento\Framework\Session\SessionManagerInterface $coreSession) {
    parent::__construct($context);
    $this->_coreSession = $coreSession;
  }

  public function execute() {
    $om = $this->_objectManager;
    $session = $om->get('Magento\Checkout\Model\Session');
    $quote2 = $session->getLastRealOrder();
    $orderId = $quote2->getIncrementId();
    $order = $om->get('Magento\Sales\Model\Order')->loadByIncrementId($orderId);
    if ($order->getState() == \Magento\Sales\Model\Order::STATE_NEW) {
      $order->setStatus(\Magento\Sales\Model\Order::STATE_CANCELED);
      $order->addStatusToHistory(\Magento\Sales\Model\Order::STATE_CANCELED);
      $order->addStatusHistoryComment('Duitku Payment | ' . 'Pop up Payment close - ' . 'by User | statusCode:'.$_GET["resultCode"].', reference:'.$_GET["reference"]);
      $order->save();
      $order->getPayment()->cancel();
      $order->registerCancellation();
      return $this->resultRedirectFactory->create()->setPath('duitkupay/index/close');
    } else {
      return $this->resultRedirectFactory->create()->setPath('checkout/cart');
    }
  }
}
