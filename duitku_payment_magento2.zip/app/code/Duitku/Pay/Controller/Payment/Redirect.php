<?php
namespace Duitku\Pay\Controller\Payment;
use Exception;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Controller\ResultFactory;

class Redirect extends \Magento\Framework\App\Action\Action {
  protected $_checkoutSession;
  protected $_logger;
  protected $_coreSession;
  public function __construct(\Magento\Framework\App\Action\Context $context, \Magento\Framework\Session\SessionManagerInterface $coreSession) {
    parent::__construct($context);
    $this->_coreSession = $coreSession;
  }

  public function execute() {
    $objectManager = $this->_objectManager;
    $session = $objectManager->get('Magento\Checkout\Model\Session');
    $lastOrder = $session->getLastRealOrder();

    $config = $objectManager->get('Magento\Framework\App\Config\ScopeConfigInterface');

    $orderIncrementId = $lastOrder->getIncrementId();
    $orderId = $lastOrder->getId();
    $orderData = $objectManager->create('Magento\Sales\Model\Order')->load($orderId);

    $apiKey = $config->getValue('payment/duitkupay/api_key', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    $merchantCode = $config->getValue('payment/duitkupay/merchant_code', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

    $billingAddressData = $orderData->getBillingAddress();
    $shippingAddressData = $orderData->getShippingAddress();
    $itemsData = $orderData->getAllItems();
    $shippingAmountData = $orderData->getShippingAmount();
    $shippingTaxAmountData = $orderData->getShippingTaxAmount();
    $taxAmountData = $orderData->getTaxAmount();

    $params = array(
      "merchantCode" => $merchantCode,
      "merchantOrderId" => $orderId,
      "merchantUserInfo" => $billingAddressData->getEmail(),
      "productDetails" => "Order => #".$orderId,
      "additionalParam" => $billingAddressData->getFirstname()." ".$billingAddressData->getLastname(),
      "email" => $billingAddressData->getEmail(),
      "phoneNumber" => $billingAddressData->getTelephone(),
    );

    $itemDetailParams = array();
    foreach ($itemsData as $value) {
      $item = array(
        'name' => $this->repString($this->getName($value->getName())),
        'price' => (int)($value->getPrice() * $value->getQtyOrdered()),
        'quantity' => (int)$value->getQtyOrdered(),
      );
      $itemDetailParams[] = $item;
    }

    if ($shippingAmountData > 0) {
      $shippingItem = array(
        'name' => 'Shipping Amount',
        'price' => (int)$shippingAmountData,
        'quantity' => 1
      );
      $itemDetailParams[] = $shippingItem;
    }

    if ($shippingTaxAmountData > 0) {
      $shippingTaxItem = array(
        'name' => 'Shipping Tax',
        'price' => (int)$shippingTaxAmountData,
        'quantity' => 1
      );
      $itemDetailParams[] = $shippingTaxItem;
    }

    if ($taxAmountData > 0) {
      $taxItem = array(
        'name' => 'Tax',
        'price' => (int)$taxAmountData,
        'quantity' => 1
      );
      $itemDetailParams[] = $taxItem;
    }

    $paymentAmount = 0;
    foreach ($itemDetailParams as $item) {
      $paymentAmount += $item['price'];
    }

    $billingAddressParams = array(
      "firstName" => $billingAddressData->getFirstname(),
      "lastName" => $billingAddressData->getLastname(),
      "address" => $billingAddressData->getStreet()[0],
      "city" => $billingAddressData->getCity(),
      "postalCode" => $billingAddressData->getPostcode(),
      "phone" => $billingAddressData->getTelephone(),
      "countryCode" => $billingAddressData->getCountryId()
    );

    $shippingAddressParams = array(
      "firstName" => $shippingAddressData->getFirstname(),
      "lastName" => $shippingAddressData->getLastname(),
      "address" => $shippingAddressData->getStreet()[0],
      "city" => $shippingAddressData->getCity(),
      "postalCode" => $shippingAddressData->getPostcode(),
      "phone" => $shippingAddressData->getTelephone(),
      "countryCode" => $shippingAddressData->getCountryId()
    );

    $customerDetailParams = array(
      "firstName" => $billingAddressData->getFirstname(),
      "lastName" => $billingAddressData->getLastname(),
      "email" => $billingAddressData->getEmail(),
      "phoneNumber" => $billingAddressData->getTelephone()
    );

    $signature = md5($merchantCode.$orderId.$paymentAmount.$apiKey);

    $customerDetailParams['billingAddress'] = $billingAddressParams;
    $customerDetailParams['shippingAddress'] = $shippingAddressParams;
    $params["itemDetails"] = $itemDetailParams;
    $params["customerDetail"] = $customerDetailParams;
    $params["paymentAmount"] = $paymentAmount;
    $params["signature"] = $signature;
    $url = "https://dev-new.duitku.com/api/merchant/createInvoice";

    // echo "<pre>".var_export($params)."</pre>";

    if (extension_loaded('curl')) {
      try {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
          'Content-Type: application/json'
        ));
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));

        // Receive server response ...
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $server_output = curl_exec($ch);

        curl_close ($ch);

        $respond = json_decode($server_output);

        if ($respond->statusCode == '00') {
          $statRespond = array(
            "status" => $respond->statusCode,
            "reference" => $respond->reference,
            "message" => $respond->statusMessage
          );
        }else{
          $statRespond = array(
            "status" => $respond->statusCode,
            "message" => $respond->statusMessage
          );
        }

        $result = $this->resultFactory->create(ResultFactory::TYPE_JSON);
        $result->setData($statRespond);
        return $result;

      } catch (Exception $e) {
        error_log($e->getMessage());
        echo $e->getMessage();
      }
    }else{
      error_log("Duitku payment need curl extension, please enable curl extension in your web server");
      echo "Duitku payment need curl extension, please enable curl extension in your web server";
    }
  }

  public function setValue($order_id) {
    $this->_coreSession->start();
    $this->_coreSession->setMessage($order_id);
  }

  public function setSessionData($key, $value) {
    return $this->_checkoutSession->setData($key, $value);
  }

  public function getSessionData($key, $remove = false) {
    return $this->_checkoutSession->getData($key, $remove);
  }

  private function repString($str) {
    return preg_replace("/[^a-zA-Z0-9]+/", " ", $str);
  }

  private function getName($s) {
    $max_length = 20;
    if (strlen($s) > $max_length) {
      $offset = ($max_length - 3) - strlen($s);
      $s = substr($s, 0, strrpos($s, ' ', $offset));
    }
    return $s;
  }
}
