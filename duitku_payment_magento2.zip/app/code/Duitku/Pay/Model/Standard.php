<?php
namespace Duitku\Pay\Model;
class Standard extends \Magento\Payment\Model\Method\AbstractMethod {
  const TRX_STATUS_SETTLEMENT = 'settlement';
  const ORDER_STATUS_EXPIRE = 'expire';
  protected $_code = 'duitkupay';

  protected $_isInitializeNeeded = true;
  protected $_canUseInternal = true;
  protected $_canUseForMultishipping = false;

  protected $_formBlockType = 'duitkupay/form';
  protected $_infoBlockType = 'duitkupay/info';

  public function getOrderPlaceRedirectUrl() {
    return 'http://www.google.com/';
  }
}

?>
