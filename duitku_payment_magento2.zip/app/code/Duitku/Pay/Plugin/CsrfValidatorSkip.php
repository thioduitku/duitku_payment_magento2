<?php
namespace Duitku\Pay\Plugin;
class CsrfValidatorSkip {
  public function aroundValidate($subject, \Closure $proceed, $request, $action) {
    if ($request->getModuleName() == 'duitkupay') {
      return;
    }
    $proceed($request, $action);
  }
}
